/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>

#include <stdio.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/I2C.h>
#include <ti/drivers/UART.h>
#include <ti/drivers/Timer.h>


/* Driver configuration */
#include "ti_drivers_config.h"

// Problem Description:
//
// Need to modify the code to do the following using a task scheduler
// * check buttons every 200ms
// * check temperature every 500ms
// * update the LED to turn off or on when heat or no heat is indicated (LED on = heat, LED off = no heat)
// * If you push the decrease button it decreases the threshold or setpoint value of the temperature by 1 degree every 200ms
// * If you push the increase button it increases the threshold or setpoint value of the temperature by 1 degree every 200ms
// * If the temperature is less than the setpoint or threshold value, then the LED light turns on (controlling a heater)
// * If the temperature is greater than the setpoint or threshold value, then the LED light turns off.
// * output to the server(via UART) every 1 second or 1000ms in this format: DISPLAY(snprintf(output, 64, "<%02d,%02d,%d,%04d>\n\r", temperature, setpoint, heat, seconds))

// Solution:
//
// Using a Task scheduler and a timer I was able to perform all of the tasks above simultaneously.
// I was able to capture the button presses using GPIO interrupt callback
// I was able to capture the temperature reading every 200 ms using the I2C function
// I was able to turn on and off the LED when the temperature was greater or less than the setpoint temp using GPIO Write
// All of these components working together allow me to demonstrate that I can increase the temp setpoint using the left side button
// and the light will illuminate if the board temp sensor is cooler than the setpoint. Once the board reaches a temp higher than the set point, the LED will turn off.
// Additionally, there is an out put written to the terminal every second telling us the current temperature, the setpoint (default is 30), if heat is on (using 0 or 1) and the seconds that have passed.




#define TRUE 1
#define FALSE 0

#define NUMBER_OF_TASKS 3
#define GLOBAL_PERIOD 10000 //milliseconds

/* Global variables used for our tasks*/
int16_t temperature;
int16_t setpoint = 30;
int16_t heat = 0;
int16_t seconds = 1;

int16_t currentTask = 0;

// A single task in the task list
struct task_entry
{
    void (*f)();    // Function to call to perform the task.
    int elapsed_time; // Amount of time since last triggered
    int period;       // Period of the task in ms
    char triggered; // Whether or not the task was triggered.
};

// Forward declaration
void task_one();
void task_two();
void task_three();

// The task list
struct task_entry tasks[NUMBER_OF_TASKS] =
{
     {&task_one,200,200, FALSE},
     {&task_two,500,500, FALSE},
     {&task_three,1000,1000, FALSE}
};

// Initializing GPIO Interrupt variables
uint_least8_t decreaseButton = 0;
uint_least8_t increaseButton = 0;



/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn0(uint_least8_t index)
{
    /* Toggle the temp threshold to decrease by one degree */
    decreaseButton = 1;
}

/*
 *  ======== gpioButtonFxn1 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_1.
 *  This may not be used for all boards.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn1(uint_least8_t index)
{
    /* Toggle the temp threshold to increase by one degree */
    increaseButton = 1;
}



/*
 *  ======== Timer Function ========
 *  This function allows us to use a timer to facilitate all of the
 *  required capture of information at different periodic intervals.
 */
// Driver Handles - Global variables
Timer_Handle timer0;

char TimerFlag = FALSE;
char ready_tasks = FALSE;

// Global period to used in the initTimer()
int global_period = GLOBAL_PERIOD;

// Will use the timer facilities
// Need to initialize the timer, and check timer intervals for tasks in callback
void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    TimerFlag = TRUE;

    // Set ready_tasks to true, if any task interval has expired
    int x = 0;
    // Walk through each task.
    for (x = 0; x < NUMBER_OF_TASKS; x++)
    {
        // check if task's interval has expired
        if (tasks[x].elapsed_time >= tasks[x].period)
        {
            // BING! This task's timer is up
            // SET it's flag, and the global flag
            tasks[x].triggered = TRUE;
            ready_tasks = TRUE;
            // Reset the elapsed_time
            //tasks[x].elapsed_time = 0;
        }
        else
        {
            tasks[x].elapsed_time += global_period;
        }
    }

}

void initTimer(void)
{
    Timer_Params params;

    // Init the driver
    Timer_init();

    // Configure the driver
    Timer_Params_init(&params);
    params.period = 1000000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;

    // Open the driver
    timer0 = Timer_open(CONFIG_TIMER_0, &params);

    if (timer0 == NULL) {
        /* Failed to initialized timer */
        while (1) {}
    }
    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        /* Failed to start timer */
        while (1) {}
    }
}



#define DISPLAY(x) UART_write(uart, &output, x);

/*
 *  ======== UART to turn LED off/on ========
 *  This function allows us the ability to write to the server
 *  every second in this format:
 *  DISPLAY(snprintf(output, 64, "<%02d,%02d,%d,%04d>\n\r", temperature, setpoint, heat, seconds))
 */
// UART Global Variables
char output[64];
int bytesToSend;

// Driver Handles - Global variables
UART_Handle uart;

void initUART(void)
{
    UART_Params uartParams;

    // Init the driver
    UART_init();

    // Configure the driver
    UART_Params_init(&uartParams);
    uartParams.writeDataMode = UART_DATA_BINARY;
    uartParams.readDataMode = UART_DATA_BINARY;
    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.baudRate = 115200;

    // Open the driver
    uart = UART_open(CONFIG_UART_0, &uartParams);

    if (uart == NULL) {
        /* UART_open() failed */
        while (1);
    }
}



/*
 *  ======== I2C Temperature Read ========
 *  This function allows us to capture the temperature reading
 */
static const struct {
    uint8_t address;
    uint8_t resultReg;
    char *id;
}

sensors[3] = {
                { 0x48, 0x0000, "11X" },
                { 0x49, 0x0000, "116" },
                { 0x41, 0x0001, "006" }
};

uint8_t txBuffer[1];
uint8_t rxBuffer[2];
I2C_Transaction i2cTransaction;

// Driver Handles - Global variables
I2C_Handle i2c;

// Make sure you call initUART() before calling this function.
void initI2C(void)
{
    int8_t i, found;
    I2C_Params i2cParams;

    DISPLAY(snprintf(output, 64, "Initializing I2C Driver - "));

    // Init the driver
    I2C_init();

    // Configure the driver
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;

    // Open the driver
    i2c = I2C_open(CONFIG_I2C_0, &i2cParams);
    if (i2c == NULL)
    {
        DISPLAY(snprintf(output, 64, "Failed\n\r"))
        while (1);
    }

    DISPLAY(snprintf(output, 32, "Passed\n\r"))

    // Boards were shipped with different sensors.
    // Welcome to the world of embedded systems.
    // Try to determine which sensor we have.
    // Scan through the possible sensor addresses

    /* Common I2C transaction setup */
    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readBuf = rxBuffer;
    i2cTransaction.readCount = 0;

    found = false;

    for (i=0; i<3; ++i)
    {
        i2cTransaction.slaveAddress = sensors[i].address;
        txBuffer[0] = sensors[i].resultReg;

        DISPLAY(snprintf(output, 64, "Is this %s? ", sensors[i].id))

        if (I2C_transfer(i2c, &i2cTransaction))
        {
            DISPLAY(snprintf(output, 64, "Found\n\r"))
                found = true;
                break;
        }
        DISPLAY(snprintf(output, 64, "No\n\r"))
    }

        if(found)
        {
            DISPLAY(snprintf(output, 64, "Detected TMP%s I2C address:%x\n\r", sensors[i].id, i2cTransaction.slaveAddress))
        }

        else
        {
            DISPLAY(snprintf(output, 64, "Temperature sensor not found, contact professor\n\r"))
        }
    }

    int16_t readTemp(void)
    {
        int16_t temperature = 0;

        i2cTransaction.readCount = 2;
        if (I2C_transfer(i2c, &i2cTransaction))
        {
            /*
            * Extract degrees C from the received data;
            * see TMP sensor datasheet
            */
            temperature = (rxBuffer[0] << 8) | (rxBuffer[1]);
            temperature *= 0.0078125;

            /*
            * If the MSB is set '1', then we have a 2's complement
            * negative value which needs to be sign extended
            */
            if (rxBuffer[0] & 0x80)
            {
                temperature |= 0xF000;
            }
        }

        else
        {
            DISPLAY(snprintf(output, 64, "Error reading temperature sensor (%d)\n\r",i2cTransaction.status));
            DISPLAY(snprintf(output, 64, "Please power cycle your board by unplugging USB and plugging back in.\n\r"))
        }

        return temperature;
}

// Task Scheduler - how to process tasks with different periods
// The project has 3 tasks, each with a different period
// See zybooks reference Section 4 for more info on Task Schedulers

// Check the current button if pressed and increase/decrease the setpoint value every 200ms
void task_one()
{
    if (tasks[currentTask].elapsed_time >= tasks[currentTask].period)
    {
        if(increaseButton == 1 )
        {
            setpoint++; //Increase setPoint
            increaseButton = 0; //Reset the increaseButton
        }
        if(decreaseButton == 1 )
        {
            setpoint--; //Decrease setPoint
            decreaseButton = 0; //Reset the decreaseButton
        }
    }
}

// Check the current temperature and turn on/off the LED every 500ms
void task_two()
{
    if (tasks[currentTask].elapsed_time >= tasks[currentTask].period)
    {
        temperature = readTemp(); // Read current Temp
        if(temperature > setpoint)
        {
            // using GPIO_write to turn the LED off
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
            heat = FALSE; //Turn off heat indicator
        }
        else
        {
            // using GPIO_write to turn the LED on
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            heat = TRUE; //Turn on heat indicator
        }
    }
}

// Output the temperature/setpoint/heat/seconds every 1 second
void task_three()
{
    if (tasks[currentTask].period >= tasks[currentTask].period)
    {
        DISPLAY(snprintf(output, 64, "<%02d,%02d,%d,%04d>\n\r", temperature, setpoint, heat, seconds)); //Print values to terminal
    }
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    /* Call driver init functions */
    GPIO_init();

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Turn on user LED */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    /*
     *  If more than one input pin is available for your device, interrupts
     *  will be enabled on CONFIG_GPIO_BUTTON1.
     */
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1) {
        /* Configure BUTTON1 pin */
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

        /* Install Button callback */
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }


    initUART();
    initI2C();
    initTimer();

    // Loop forever
    while (1)
    {

        // Wait for task intervals(periods) to elapse
        while (!ready_tasks)
        {
            // Process the tasks for which the interval has to expire
            for(currentTask = 0; currentTask < NUMBER_OF_TASKS; currentTask++)
            {
                if(tasks[currentTask].triggered)
                {
                    tasks[currentTask].f();
                    //reset
                    tasks[currentTask].triggered = FALSE;
                }
            }
            TimerFlag = TRUE;
        }
        // When TimerFlag becomes true, execute the reset process
        while(TimerFlag == TRUE)
        {
            TimerFlag = FALSE;
            currentTask = 0;
            ready_tasks = FALSE;
            seconds += 1; // Increase the seconds ticker for the print console/terminal
        }
    }

    return (NULL);
}
