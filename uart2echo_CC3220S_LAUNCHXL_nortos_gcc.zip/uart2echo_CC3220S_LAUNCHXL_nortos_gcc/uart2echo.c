/*
 * Copyright (c) 2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

// Problem Description:
//
// Need to be able to turn LED off/on when typing OFF and ON into the console using only
// one byte of RAM as outlined in the "CS 350 Milestone Two UART GPIO Lab Guide".
// The following were the requirements:
// * Use only one byte of RAM for the serial buffer ( char input; ).
// * Use only one byte of RAM for the state ( unsigned char state; ).
// * Receive only one character at a time from the UART and it is not buffered.
// * Turn on an LED when a user types ON into the console.
// * Turn off the LED when a user types OFF into the console.

// Solution:
// Using three states via Enum I was able to set the states using a switch case
// that looked for specific criteria. Each letter was read in and passed through the cases
// to match the criteria for turning off and on the light. Successfully, the light starts out on
// in a default setting and then turns off when typing OFF into the terminal. The light successfully
// turns on when typing On into the terminal.

/*
 *  ======== uart2echo.c ========
 */
#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/UART2.h>

/* Driver configuration */
#include "ti_drivers_config.h".

// Emum creating the three states that we will use in this project
// LED_on, LED_off, and LED_default
typedef enum states
        {
            LED_on,
            LED_off,
            LED_default
        }State;
/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    char input;
    // created this variable to store the previous input captured from user
    char previousInput;
    // created this variable to continue storing input from user.
    char previousPreviousInput;
    const char echoPrompt[] = "Echoing characters:\r\n";
    UART2_Handle uart;
    UART2_Params uartParams;
    size_t bytesRead;
    size_t bytesWritten = 0;
    uint32_t status     = UART2_STATUS_SUCCESS;
    // setting the current state of the LED to LED_default
    State currentLEDState = LED_default;
    // constant variables created to be checked against user inputs later
    // these variables never change.
    char constO = 'O';
    char constF = 'F';
    char constNull = 'C';
    bool firstFInput = false;


    /* Call driver init functions */
    GPIO_init();

    /* Configure the LED pin */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);

    /* Create a UART where the default read and write mode is BLOCKING */
    UART2_Params_init(&uartParams);
    uartParams.baudRate = 115200;

    uart = UART2_open(CONFIG_UART2_0, &uartParams);

    if (uart == NULL)
    {
        /* UART2_open() failed */
        while (1) {}
    }

    /* Turn on user LED to indicate successful initialization */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    UART2_write(uart, echoPrompt, sizeof(echoPrompt), &bytesWritten);

    /* Loop forever echoing */
    while (1)
    {
        bytesRead = 0;
        while (bytesRead == 0)
        {
            status = UART2_read(uart, &input, 1, &bytesRead);

            if (status != UART2_STATUS_SUCCESS)
            {
                /* UART2_read() failed */
                while (1) {}
            }
        }
        /* Loop forever to take input and turn off and on LED */
            /*
             *  This switch case allows for the program to read in user input being typed in one letter/byte at a time.
             *  If the user types 'O' for the first letter the user could be writing "ON" or "OFF"
             *  so we store that "O" as previous input, we then check the case if "N" is entered and then if it is, it first checks
             *  if the letter "O was entered as previous input, if so then the user successfully entered the word "ON" and the currentLEDState
             *  switches to LED_on, and then the previous input variable is reset. The same process happens if the user types "OFF". The program
             *  checks to make sure "O" was entered first and stored as previousInput, and then it checks if the first "F" letter is false, meaning
             *  the letter "F" has not been entered, and then if that passes then the bool firstFInput changes to true and the previousPreviousInput is
             *  set to the second "F" input followed by a break. Now that the first "F" letter is stored in previousPreviousInput, we check for that
             *  and if it is equal to our constF then the currentLEDState changes to LED_off and all variables are now reset. The default case allows
             *  for the LED default status to be set to LED_default in which the program starts with it in LED_default state and the light is on.
             *
             *  Now that I explained the cases, below that is where the actual action takes place and the LED switches ON and OFF. This is done using a
             *  check to see if the currentLEDState is LED_on then using GPIO_write we are able to turn on the light. If the currentLEDState is LED_off
             *  then using GPIO_write we are able to turn off the light.
             */
        switch (input)
        {

            case 'O':
                previousInput = input;
                break;
            case 'N':
                if (previousInput == constO)
                {
                    currentLEDState = LED_on;
                    previousInput = constNull;
                }
                break;
            case 'F':
                if (previousInput == constO)
                {
                    if (firstFInput == false)
                    {
                        firstFInput = true;
                        previousPreviousInput = input;
                        break;
                    }
                    if (previousPreviousInput == constF)
                    {
                        currentLEDState = LED_off;
                        previousInput = constNull;
                        firstFInput = false;
                        previousPreviousInput = constNull;
                    }
                }
                break;
            default:
                currentLEDState = LED_default;
                previousInput = constNull;
                previousPreviousInput = constNull;
                currentLEDState = constNull;
                break;
        }

        if (currentLEDState == LED_on)
        {
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
        }
        if (currentLEDState == LED_off)
        {
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
        }


        bytesWritten = 0;
        while (bytesWritten == 0)
        {
            status = UART2_write(uart, &input, 1, &bytesWritten);

            if (status != UART2_STATUS_SUCCESS)
            {
                /* UART2_write() failed */
                while (1) {}
            }
        }
    }
}
