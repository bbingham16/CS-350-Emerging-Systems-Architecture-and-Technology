/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>
#include <unistd.h>
#include <stdio.h>
#include <stdbool.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>

/* Driver configuration */
#include "ti_drivers_config.h"

/* Code added from lab guide*/
#include <ti/drivers/Timer.h>

// Problem Description:
//
// Using a state machine continuously blink SOS and OK in Morse code on the green and red LEDs
// If a button is pressed, the state machine should handle that input after the completion of
// SOS or OK, and then switch the message upon completion of that current word.


// Solution:
//
// The solution was completed using states described as Default_state which starts the SOS
// sequence, SOS_complete which is called after SOS has completed running, and the togglePressed function is checked
// to see if it was pressed during the sequence. If the toggle was pressed, the messageOK function is called
// and then the current state changes to OK_complete. The toggle is checked once more and if it is false, the
// MessageSOS function is called and th3e state returns to the default state. IF the toggle button was pressed, then
// messageOK is called to loop again. GPIO_write was used to toggle the LED's on and off and I used usleep to
// create the periods of time between each letter and between each word.
// Dot = Red LED on for 500ms (dotDelay variable)
// Dash = green LED on for 1500ms (dashSlowDelay variable) and I used a faster dash Delay (dashFastDelay variable)
// 3*500ms between characters (timeInBetweenLettersDelay * dotDelay)
// 7*500ms between words (timeInBetweenWordsDelay * dotDelay)


// Emum creating the three states that we will use in this project
// SOS_complete, OK_complete, and Default_state
// currentState changes to SOS_complete if the messageSOS function completes the sequence of blinking for each letter, S, O, and S.
// currentState changes to OK_complete if the messageOK function completes the sequence of blinking for each letter, O, and K.
// currentState starts in Default_state which starts the messageSOS function automatically.
typedef enum states
        {
            SOS_complete,
            OK_complete,
            Default_state
        }State;

// As mentioned above in the solution, these variables represent the duration of times between letters and words.
// To prevent magic numbers, I saved the numbness to variables.
// Dot = Red LED on for 500ms (dotDelay variable)
int dotDelay = 500000;
// Dash = green LED on for 1500ms (dashSlowDelay variable)
int dashSlowDelay = 1500000;
// faster dash Delay (dashFastDelay variable)
int dashFastDelay = 375000;
// 3*500ms between characters (timeInBetweenLettersDelay)
int timeInBetweenLettersDelay = 3;
// 7*500ms between words (timeInBetweenWordsDelay)
int timeInBetweenWordsDelay = 7;

// setting the currentState to Default_state to call messageSOS upon start
State currentState= Default_state;

// setting the togglePressed to start as false. This bool will change every time the
// toggle button is pressed.
static bool togglePressed = false;


/* Timer */
    /* I had a hard time implementing this into my code successfully. I couldn't find an example on Texas instruments website showing
     * this code being used as an example. I have emailed my professor asking for help on this issue, so instead of deleting it out of my code
     * entirely, I am just commenting it out in hopes I can fix this area with his advice and resubmit.
     */
//void timerCallback(Timer_Handle myHandle, int_fast16_t status)
//{
//}

//void initTimer(void)
//{
   // Timer_Handle timer0;
    //Timer_Params params;
    //Timer_init();
    //Timer_Params_init(&params);
    //params.period = 1000000;
    //params.periodUnits = Timer_PERIOD_US;
    //params.timerMode = Timer_CONTINUOUS_CALLBACK;
    //params.timerCallback = timerCallback;

    //timer0 = Timer_open(CONFIG_TIMER_0, &params);

    //if (timer0 == NULL) {
        /* Failed to initialized timer */
        //while (1) {}

    //}
    //if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        /* Failed to start timer */
        //while (1) {
        //}
    //}
//}


/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 *
 *  This button is set to the RED LED
 *  togglePressed true equals togglePressed false.
 *  This allows the toggle button to control the LED's
 */
void gpioButtonFxn0(uint_least8_t index)
{
    /* Toggle an RED LED */
    togglePressed = !togglePressed;
}

/*
 *  ======== gpioButtonFxn1 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_1.
 *  This may not be used for all boards.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 *
 *  This button is set to the GREEN LED
 *  togglePressed true equals togglePressed false.
 *  This allows the toggle button to control the LED's
 */
void gpioButtonFxn1(uint_least8_t index)
{
    /* Toggle an GREEN LED */
    togglePressed = !togglePressed;
}

/*
 *  ====MorseLetterS(), MorseLetterO(), MorseLetterK()====
 *  These functions are used to spell out SOS and OK using individual letters
 *  of S, O, and K. Using GPIO_write I am able to turn on and off the LED's.
 *  I used usleep to allow for the proper wait times in between letters.
 *   See solution for more details.
 */
void MorseLetterS()
{
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
    usleep(dotDelay);
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
    usleep(dotDelay);
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
    usleep(dotDelay);
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
    usleep(dotDelay);
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
    usleep(dotDelay);
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
    usleep(timeInBetweenLettersDelay * dotDelay);
}

void MorseLetterO()
{
    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
    usleep(dashSlowDelay);
    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
    usleep(dashFastDelay);
    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
    usleep(dashSlowDelay);
    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
    usleep(dashFastDelay);
    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
    usleep(dashSlowDelay);
    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
    usleep(timeInBetweenLettersDelay * dotDelay);
}

void MorseLetterK()
{
    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
    usleep(dashSlowDelay);
    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
    usleep(dotDelay);
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
    usleep(dashSlowDelay);
    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
    usleep(timeInBetweenLettersDelay * dotDelay);
}

// Function called to create Morse code for the word OK
// Added in a longer wait time using usleep for the time
// between words.
// currentState is changed to OK_complete when the OK sequence has finished.
void messageOK()
{
    MorseLetterO();
    MorseLetterK();

    usleep(timeInBetweenWordsDelay * dotDelay);

    currentState = OK_complete;
}

// Function called to create Morse code for the word SOS
// Added in a longer wait time using usleep for the time
// between words.
// currentState is changed to SOS_complete when the SOS sequence has finished.
void messageSOS()
{
    MorseLetterS();
    MorseLetterO();
    MorseLetterS();

    usleep(timeInBetweenWordsDelay * dotDelay);

    currentState = SOS_complete;
}

// MorseCodeCheck uses the states to drive the program.
void MorseCodeCheck()
{
    while (1)
    {   // if current state is Default_state then messageSOS() function is called.
        if(currentState == Default_state)
        {
            messageSOS();
        }
        // else if current state is SOS_complete then that means the messageSOS() function
        // has completed and now we are checking to see if the toggle button is pressed.

        else if(currentState == SOS_complete)
        {
            // if the toggle button was pressed, the messageOK() function is called and the Morse
            // code for OK starts.
            if(togglePressed)
            {
                messageOK();
            }
            // else the current state changes back to the defult state and the messageSOS starts all over again.
            else
            {
                currentState = Default_state;
            }
        }
        // else if the currentState is OK_complete that means the messageOK() function
        // has completed and now we are checking to see if the toggle button was pressed again
        // switching the toggle button to false, then the currentState changes back to the Default_state
        // where messageSOS() is called once more. If the toggle button remains true and was not pushed again,
        // then messageOK is called again until the button is pressed.
        // This is an exact replica of the functionality that was shown in the demo video.
        else if(currentState == OK_complete)
        {
            if(togglePressed)
            {
                messageOK();
            }
            else
            {
                currentState = Default_state;
            }
        }
    }
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    /* Call driver init functions */
    GPIO_init();

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Turn on user LED */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    /*
     *  If more than one input pin is available for your device, interrupts
     *  will be enabled on CONFIG_GPIO_BUTTON1.
     */
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1) {
        /* Configure BUTTON1 pin */
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

        /* Install Button callback */
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

    // Calling MorseCodeCheck() to start the evaluation of the current states and start the program.
    MorseCodeCheck();

    return (NULL);
}


